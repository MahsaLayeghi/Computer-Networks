package ir.arcinc.tls;

import ir.arcinc.tls.Commons.Initializer;

import java.util.Observable;

/**
 * Created by tahae on 4/18/2016.
 */
public class Main extends Observable {

    public static void main(String[] args) {new Initializer();}
}
